package mypair;

public interface PairInterface<T> {
	public void setFirst(T first);
	public T getFirst();
	public void setSecond(T second);
	public T getSecond();
}
